import { useState } from "react";
import TodoTemplate from "./components/TodoTemplate";

function App() {
  const [value, setValue] = useState("");

  const onChange = event => {
    setValue(event.target.value);
  };

  return (
    <TodoTemplate>
      <form>
        <input
          placeholder="할 일을 입력하세요."
          onChange={onChange}
          value={value}
        />
        <button type="button">등록</button>
      </form>
    </TodoTemplate>
  );
}

export default App;
